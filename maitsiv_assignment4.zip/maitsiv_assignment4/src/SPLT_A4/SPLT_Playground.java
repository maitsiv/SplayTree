package SPLT_A4;

public class SPLT_Playground {
  public static void main(String[] args){
    //genTest();
	  testA();
  }
  
  public static void genTest(){
    SPLT tree= new SPLT();
    tree.insert("hello");
    tree.insert("world");
    tree.insert("my");
    tree.insert("name");
    tree.insert("is");
    tree.insert("blank");
    tree.remove("hello");
    System.out.println("size is "+tree.size());
    
    printLevelOrder(tree);
  }
  
  public static void testA() {
	  SPLT atree = new SPLT();
	  /*atree.insert("0");
	  atree.insert("C");
	  atree.insert("A");
	  atree.insert("B");
	  atree.insert("E");
	  atree.insert("D");
	  atree.insert("F");
	  atree.insert("M");
	  atree.insert("H");
	  atree.insert("I");*/
	  
	  /*atree.insert("0");
	  atree.insert("x");
	  atree.insert("n");
	  atree.insert("l");
	  atree.insert("a");
	  atree.remove("l");
	  atree.insert("c");
	  atree.remove("x");*/
	  
	
	  
	  
	  
	  //atree.insert("blue");
	  atree.insert("boy");
	 // atree.remove("apple");
	  atree.insert("apple");
	  atree.insert("cat");
	  //atree.remove("apple");
	  
	 

	  //atree.empty();
	  System.out.println("empty:"+atree.empty());

	  atree.contains("apple");
	  //atree.findMin();
	  //atree.findMax();
	  //System.out.println("height:"+atree.height());
	  //System.out.println("size is "+atree.size());
	  
	  /*atree.remove("C");
	  atree.remove("A");
	  atree.remove("D");
	  atree.insert("A");
	  atree.insert("A");*/
	  
	  printLevelOrder(atree);
	  //System.out.println("size is "+atree.size());


	  
  }

    static void printLevelOrder(SPLT tree){ 
    //will print your current tree in Level-Order...Requires a correct height method
    //https://en.wikipedia.org/wiki/Tree_traversal
      int h=tree.getRoot().getHeight();
      for(int i=0;i<=h;i++){
        System.out.print("Level "+i+":");
        printGivenLevel(tree.getRoot(), i);
        System.out.println();
      }
      
    }
    static void printGivenLevel(BST_Node root,int level){
      if(root==null)return;
      if(level==0)System.out.print(root.data+" ");
      else if(level>0){
        printGivenLevel(root.left,level-1);
        printGivenLevel(root.right,level-1);
      }
    }
   static void printInOrder(BST_Node root){
      if(root!=null){
      printInOrder(root.getLeft());
      System.out.print(root.getData()+" ");
      printInOrder(root.getRight());
      }
  }
  
}
