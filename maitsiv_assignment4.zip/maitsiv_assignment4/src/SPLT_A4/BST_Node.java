package SPLT_A4;



public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  BST_Node par; //parent...not necessarily required, but can be useful in splay tree
  boolean justMade; //could be helpful if you change some of the return types on your BST_Node insert.
            //I personally use it to indicate to my SPLT insert whether or not we increment size.
  
  BST_Node(String data){ 
    this.data=data;
    this.justMade=true;
  }
  
  BST_Node(String data, BST_Node left,BST_Node right,BST_Node par){ //feel free to modify this constructor to suit your needs
    this.data=data;
    this.left=left;
    this.right=right;
    this.par=par;
    this.justMade=true;
  }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is (meaning also make sure they do in fact return data,left,right respectively)

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }

  // --- end used for testing -------------------------------------------



  
  public BST_Node containsNode(String s){ 
	  if (s.equals(this.data)) {
		  splay(this);
		  return this;
	  } else if (s.compareTo(this.data) < 0) {
		  if (this.left == null) {
			  splay(this);
			  return this;}
		  else {
		  return this.left.containsNode(s);
		  }
	  } else if (s.compareTo(this.data) > 0) {
		  if (this.right == null) { 
			  splay(this);
			  return this;}
		  else {		  
		  return this.right.containsNode(s);
		  }	  
	  }	  

	  return null; 
  
  } 
  public BST_Node insertNode(String s){ 
	  
	  	  if (s.compareTo(this.data) == 0) {
	  		  splay(this);
	  		  this.justMade = false;
	  		  return this;
	  	  } else {
	 
		  BST_Node newNode = new BST_Node(s);
		  if (s.compareTo(this.data) < 0) {
			  if (this.left == null) {
				  this.left = newNode;
				  this.left.par = this;
				  splay(newNode);
				  return newNode;
			  } else {
				  return this.left.insertNode(s);
			  }
		  }	  
		  if (s.compareTo(this.data) > 0) {
			  if (this.right == null) {
				  this.right = newNode;
				  this.right.par = this;
				  splay(newNode);
				  return newNode;
			  } else {
				  return this.right.insertNode(s);
			  }
		  }
	  	  }
	  
	  return null; 
  
  } //Really same logic as above note
  public boolean removeNode(String s){	 
	  
	  return true;
  
  } //I personal do not use the removeNode internal method in my impl since it is rather easily done in SPLT, feel free to try to delegate this out, however we do not "remove" like we do in BST
  public BST_Node findMin(){ 
	  if (this.left == null) {
		  splay(this);
		  return this;
	  } else {
		  return this.left.findMin();
	  }	
	  
  } 
  public BST_Node findMax(){ 
	  if (this.right == null) {
		  splay(this);
		  return this;
	  } else {
		  return this.right.findMax();
	  }	
	  
  }
  public int getHeight(){ 
	  if (this.left == null && this.right == null) {
		  return 0;
	  }	  
	  else if (this.left != null && this.right == null) {
		   return this.left.getHeight()+ 1;
	  } else if (this.right != null && this.left == null) {
		  return this.right.getHeight() + 1;
	  } else if (this.left != null && this.right != null) {
		  return Math.max(this.right.getHeight(), this.left.getHeight()) + 1;
	  }
	 
	  return 0;
	  
	
	  
  }

  private void splay(BST_Node toSplay) {
	  
	  boolean splayed = false;
	  
	  while (splayed == false) {
		  if (toSplay.par == null) {
			  splayed = true;
		  } else {
			  BST_Node splayParent = toSplay.par;
			  if (splayParent.par == null) {
				  if(splayParent.right == toSplay) {
					  rotateLeft(toSplay);
					  splayed = true;					  
				  }
				  else if(splayParent.left == toSplay) {
					  rotateRight(toSplay);
					  splayed = true;
				  }
			  }
			  else if (splayParent.par != null) {
				  if (splayParent.par.par != null) {
					  BST_Node gg = splayParent.par.par;
					  if (gg.left == splayParent.par) {				
						  if (splayParent.par.left == toSplay.par) {
							  
							  if (splayParent.left == toSplay) {
								  rotateRightRight(toSplay);
								  gg.left = toSplay;
								  toSplay.par = gg;
							  }
								  //zig zig RR
							  else if (splayParent.right == toSplay) {
								  rotateLeftRight(toSplay);
								  gg.left = toSplay;
								  toSplay.par = gg;
								  //zig zag LR
							  }
						  }
						  else if (splayParent.par.right == toSplay.par) {
							  if (splayParent.left == toSplay) {
								  rotateRightLeft(toSplay);
								  gg.left = toSplay;;
								  toSplay.par = gg;
								  //zig zag RL
							  }
							  else if (splayParent.right == toSplay) {
								  rotateLeftLeft(toSplay);
								  gg.left = toSplay;
								  toSplay.par = gg;
								  //zig zig LL
							  } 
						  } 
					  }
					  if (gg.right == splayParent.par) {
						  if (splayParent.par.left == toSplay.par) {
							  
							  if (splayParent.left == toSplay) {
								  rotateRightRight(toSplay);
								  gg.right = toSplay;
								  toSplay.par = gg;
								  //zig zig RR
							  }
							  else if (splayParent.right == toSplay) {
								  rotateLeftRight(toSplay);
								  gg.right = toSplay;
								  toSplay.par = gg;
								  //zig zag LR
							  }
						  }
						  else if (splayParent.par.right == toSplay.par) {
							  if (splayParent.left == toSplay) {
								  rotateRightLeft(toSplay);
								  gg.right = toSplay;;
								  toSplay.par = gg;
								  //zig zag RL
							  }
							  else if (splayParent.right == toSplay) {
								  rotateLeftLeft(toSplay);
								  gg.right = toSplay;
								  toSplay.par = gg;

								  //zig zig LL
							  } 
						  } 
					  }
					  } else {
						  if (splayParent.par.left == toSplay.par) {
				  
							  if (splayParent.left == toSplay) {
								  rotateRightRight(toSplay);
								  splayed = true;
						  
								  //zig zig RR
							  }
							  else if (splayParent.right == toSplay) {
								  rotateLeftRight(toSplay);
								  splayed = true;
								  //zig zag LR
							  }
						  }
						  else if (splayParent.par.right == toSplay.par) {
							  if (splayParent.left == toSplay) {
								  rotateRightLeft(toSplay);
								  splayed = true;
								  //zig zag RL
							  }
							  else if (splayParent.right == toSplay) {
								  rotateLeftLeft(toSplay);
								  splayed = true;
								  //zig zig LL
							  } 
						  }
					  }
		  }
	  }
}
	  

	  
} //you could have this return or take in whatever you want..so long as it will do the job internally. As a caller of SPLT functions, I should really have no idea if you are "splaying or not"
   
  private void rotateLeft(BST_Node splayNode) {
	  if (splayNode.left != null) {
		  BST_Node left = splayNode.left;
		  BST_Node parent = splayNode.par;
		  splayNode.par.right = left;
		  left.par = parent;
		  splayNode.left = splayNode.par;
		  splayNode.par.par = splayNode;
		  splayNode.par = null;		  
	  } else {
		  splayNode.par.right = null;
		  splayNode.left = splayNode.par;
		  splayNode.left.par = splayNode;
		  splayNode.par = null;
	  }
	  
	  
  }
  
  private void rotateRight (BST_Node splayNode) {
	  if (splayNode.right != null) {
		  BST_Node right = splayNode.right;
		  BST_Node parent = splayNode.par;
		  splayNode.par.left = right;
		  right.par = parent;
		  splayNode.right = splayNode.par;
		  splayNode.par.par = splayNode;
		  splayNode.par = null;
		 
	  } else {
		  splayNode.par.left = null;
		  splayNode.right = splayNode.par;
		  splayNode.right.par = splayNode;
		  splayNode.par = null;
	  }
	 
  }
  
  private void rotateLeftRight (BST_Node splayNode) {
	  if (splayNode.left != null) {
		  BST_Node left = splayNode.left;
		  BST_Node parent = splayNode.par;
		  BST_Node grandparent = parent.par;

		  splayNode.par.right = left;
		  left.par = parent;
		  splayNode.left = splayNode.par;
		  splayNode.par.par = splayNode;
		  splayNode.par = grandparent;	
		  grandparent.left = splayNode;
	  } else {
		  BST_Node parent = splayNode.par;
		  BST_Node grandparent = parent.par;
		  splayNode.par.right = null;
		  splayNode.left = splayNode.par;
		  splayNode.left.par = splayNode;
		  splayNode.par = grandparent;	
		  grandparent.left = splayNode;
	  }
	  
	 
	  
	  rotateRight(splayNode);
		  
  }
  
  
  private void rotateRightLeft (BST_Node splayNode) {
	  if (splayNode.right != null) {
		  BST_Node right = splayNode.right;
		  BST_Node parent = splayNode.par;
		  BST_Node grandparent = parent.par;

		  splayNode.par.left = right;
		  right.par = parent;
		  splayNode.right = splayNode.par;
		  splayNode.par.par = splayNode;
		  splayNode.par = grandparent;
		  grandparent.right = splayNode;
		 
	  } else {
		  BST_Node parent = splayNode.par;
		  BST_Node grandparent = parent.par;
		  splayNode.par.left = null;
		  splayNode.right = splayNode.par;
		  splayNode.right.par = splayNode;
		  splayNode.par = grandparent;
		  grandparent.right = splayNode;
	  }
	 
	  rotateLeft(splayNode);
  }
  
  private void rotateLeftLeft (BST_Node splayNode) {
	  rotateLeft(splayNode.par);
	  rotateLeft(splayNode);
	  //rotate parent left then child left
  }
  
  private void rotateRightRight (BST_Node splayNode) {
	 rotateRight(splayNode.par);
	 rotateRight(splayNode);
	  //rotate parent right then child right
  }
  
  
  //I of course, will be checking with tests and by eye to make sure you are indeed splaying
                        //Pro tip: Making individual methods for rotateLeft and rotateRight might be a good idea!
  

  // --- end example methods --------------------------------------

  
  

  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  
}
