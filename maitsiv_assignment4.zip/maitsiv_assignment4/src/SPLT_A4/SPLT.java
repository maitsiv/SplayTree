package SPLT_A4;



public class SPLT implements SPLT_Interface{
  private BST_Node root;
  private int size;
  
  public SPLT() {
    this.size = 0;
  } 
  
  public BST_Node getRoot() { //please keep this in here! I need your root node to test your tree!
	while (this.root.par != null) {
		root = this.root.par;
	}	
    return root;
  }

@Override
public void insert(String s) {
	if (this.root == null) {
		BST_Node newNode = new BST_Node(s);
		this.root = newNode;
		this.size++;
		return;
	} else {
		BST_Node inserted = this.root.insertNode(s);
		this.root = inserted;
		if (this.root.justMade) {
			this.size++;
		}
		return;
	}
	
	
}

@Override
public void remove(String s) {
	if (this.size == 0 || this.root == null) {
		return;
	}
	boolean containsS = this.contains(s);
		  
	
	if (containsS) {
		if (this.root.left == null && this.root.right == null) {
			this.root = null;
			this.size--;
			return;
		}
		
		else if (this.root.right != null && this.root.left == null) {
			this.root = this.root.right;
			this.root.par = null;
			this.size--;
		} else if (this.root.left != null && this.root.right == null) {
			this.root = this.root.left;
			this.root.par = null;
			this.size--;
		}		
		else {
			BST_Node leftsub = this.root.left;
			BST_Node rightsub = this.root.right;
			//this.root = leftsub;
			leftsub.par = null;
			BST_Node max = leftsub.findMax();
			max.right = rightsub;
			rightsub.par = max;
			this.root = max;
			this.size--;
		}
		return;

} 
return;	
}


@Override
public String findMin() {
	if (this.size == 0 || this.root == null) {
		return null;
	}
	if (this.size == 1) {
		return root.data;
	}
	this.root = this.root.findMin();
	return root.data;
}

@Override
public String findMax() {
	if (this.size == 0 || this.root == null) {
		return null;
	}
	if (this.size == 1) {
		return root.data;
	}
	this.root = this.root.findMax();
	return root.data;
	
}

@Override
public boolean empty() {
	if (this.root == null || this.size == 0) {
		return true;
	}
	return false;
}

@Override
public boolean contains(String s) {
	if (this.size == 0 || this.root == null) {
		return false;
	}
	BST_Node node = this.root.containsNode(s);
	this.root = node;
	if (node.data == s) {
		return true;
}
return false;
}

@Override
public int size() {
	if (this.root == null) {
		return 0;
	}
	
	return this.size;
}

@Override
public int height() {
	if (this.size == 0 || this.root == null) {
		return -1;
	} else {
		return this.root.getHeight();
	}
	
}  

}
